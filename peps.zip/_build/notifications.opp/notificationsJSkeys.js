// Checking keys resolution.
// File used by the jschecker only
var _check_definition_of_notifications_enabled = global.Notifications_enabled
var _check_definition_of_notifications_request = global.Notifications_request
var _check_definition_of_notifications_simple = global.Notifications_simple
var _check_definition_of_notifications_support = global.Notifications_support
