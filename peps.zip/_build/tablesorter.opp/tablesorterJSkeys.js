// Checking keys resolution.
// File used by the jschecker only
var _check_definition_of_tablesorter_addparser = global.Tablesorter_addParser
var _check_definition_of_tablesorter_init = global.Tablesorter_init
