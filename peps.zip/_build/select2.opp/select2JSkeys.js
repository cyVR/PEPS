// Checking keys resolution.
// File used by the jschecker only
var _check_definition_of_select2_getselection = global.Select2_getSelection
var _check_definition_of_select2_init = global.Select2_init
var _check_definition_of_select2_setselection = global.Select2_setSelection
