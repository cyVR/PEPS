
global.nacl = require("tweetnacl");


global.Servernacl_uint8array_length = function (a){return a.length;};

global.Servernacl_binary_to_uint8array = function (a){var b =a.contents;a = new (global.Uint8Array)(b.length);var c =0;for (; c < b.length; ++c){a[c] = b[c];}return a;};

global.Servernacl_uint8array_to_binary = function (a){var c =new (global.Buffer)(a.byteLength),b =0;for (; b < c.length; ++b){c[b] = a[b];}return {contents:c,length:c.length};};

global.Servernacl_uint8array_of_int = function (a){var b =[];while (a > 0) {b.push(a & 0xFF);a >>= 8;};
return new (global.Uint8Array)(b);};

global.Servernacl_nacl_hash = function (a){return global.nacl.hash(a);};

global.Servernacl_nacl_hashLength = function (){return global.nacl.hash.hashLength;};

global.Servernacl_nacl_randomBytes = function (a){return global.nacl.randomBytes(a);};

global.Servernacl_nacl_verify = function (a,b){return global.nacl.verify(a,b);};

global.Servernacl_nacl_sign_keyPair = function (){return global.nacl.sign.keyPair();};

global.Servernacl_nacl_sign = function (a,b){return global.nacl.sign(a,b);};

global.Servernacl_nacl_sign_open = function (a,b){b = global.nacl.sign.open(a,b);return b?global.js_some(b):global.js_none;};

global.Servernacl_nacl_box_keyPair = function (){return global.nacl.box.keyPair();};

global.Servernacl_nacl_box_keyPair_fromSecretKey = function (a){return global.nacl.box.keyPair.fromSecretKey(a);};

global.Servernacl_nacl_box = function (a,b,c,d){return global.nacl.box(a,b,c,d);};

global.Servernacl_nacl_box_open = function (a,b,c,d){c = global.nacl.box.open(a,b,c,d);return c?global.js_some(c):global.js_none;};

global.Servernacl_nacl_box_before = function (a,b){return global.nacl.box.before(a,b);};

global.Servernacl_nacl_box_after = function (a,b,c){return global.nacl.box.after(a,global.none,c);};

global.Servernacl_nacl_box_open_after = function (a,b,c){b = global.nacl.box.open.after(a,b,c);return b?global.js_some(b):global.js_none;};

global.Servernacl_nacl_box_publicKeyLength = function (){return global.nacl.box.publicKeyLength;};

global.Servernacl_nacl_box_secretKeyLength = function (){return global.nacl.box.secretKeyLength;};

global.Servernacl_nacl_box_sharedKeyLength = function (){return global.nacl.box.sharedKeyLength;};

global.Servernacl_nacl_box_nonceLength = function (){return global.nacl.box.nonceLength;};

global.Servernacl_nacl_box_overheadLength = function (){return global.nacl.box.overheadLength;};

global.Servernacl_nacl_secretbox = function (a,b,c){return global.nacl.secretbox(a,b,c);};

global.Servernacl_nacl_secretbox_open = function (a,b,c){c = global.nacl.secretbox.open(a,b,c);return c?global.js_some(c):global.js_none;};

global.Servernacl_nacl_secretbox_keyLength = function (){return global.nacl.secretbox.keyLength;};

global.Servernacl_nacl_secretbox_nonceLength = function (){return global.nacl.secretbox.nonceLength;};

global.Servernacl_nacl_secretbox_overheadLength = function (){return global.nacl.secretbox.overheadLength;};

global.Servernacl_nacl_util_decodeUTF8 = function (a){return global.nacl.util.decodeUTF8(a);};

global.Servernacl_nacl_util_encodeUTF8 = function (a){return global.nacl.util.encodeUTF8(a);};

global.Servernacl_uint8array_decodeHex = function (a){var c =[],b =0;for (; b < a.length - 1; b += 2){c.push(global.parseInt(a.substr(b,2),16));}return new (global.Uint8Array)(c);};

global.Servernacl_uint8array_encodeHex = function (a){var b =global.Array.prototype.map.call(a,function (c){return (c >> 4).toString(16) + (c & 0xF).toString(16);}).join("");return b;};

global.Servernacl_nacl_util_decodeBase64 = function (a){return global.nacl.util.decodeBase64(a);};

global.Servernacl_nacl_util_encodeBase64 = function (a){return global.nacl.util.encodeBase64(a);};

global.Servernacl_hmac_sha512 = function (a,b){var c =128;a.byteLength > c && (a = global.nacl.hash(a));if (a.byteLength < c) {var d =new (global.Uint8Array)(new (global.ArrayBuffer)(c));d.set(a,0);a = d;}d = new (global.Uint8Array)(c);global.Servernacl_uint8array_fill(d,0x5c);global.Servernacl_uint8array_xor(d,a);c = new (global.Uint8Array)(c);global.Servernacl_uint8array_fill(c,0x36);global.Servernacl_uint8array_xor(c,a);return global.nacl.hash(global.Servernacl_uint8array_concat(d,global.nacl.hash(global.Servernacl_uint8array_concat(c,b))));};

global.Servernacl_pbkdf2 = function (a,b,c,d){var e =128,f =64;if (d > 4294967295 * f) {
throw "pbkdf2: derived key is too large";}var g =a;g.byteLength > e && (g = global.nacl.hash(g));if (g.byteLength < e) {var h =new (global.Uint8Array)(new (global.ArrayBuffer)(e));h.set(g,0);g = h;}var i =new (global.Uint8Array)(e);global.Servernacl_uint8array_fill(i,0x5c);global.Servernacl_uint8array_xor(i,g);var j =new (global.Uint8Array)(e);global.Servernacl_uint8array_fill(j,0x36);global.Servernacl_uint8array_xor(j,g);var k =new (global.Uint8Array)(d);function l(r){return global.nacl.hash(global.Servernacl_uint8array_concat(i,global.nacl.hash(global.Servernacl_uint8array_concat(j,r))));}function m(r){return new (global.Uint8Array)([r >> 24 & 0xFF,r >> 16 & 0xFF,r >> 8 & 0xFF,r & 0xFF]);}function n(r,s,t){r = l(global.Servernacl_uint8array_concat(r,m(t)));var u =new (global.Uint8Array)(r);t = 1;for (; t < s; t++){r = l(r);global.Servernacl_uint8array_xor(u,r);}return u;}var o =d / f,p =0,q =1;for (; q <= o; q++){k.set(n(b,c,q),p);p += f;}p < d && k.set(n(b,c,q).subarray(0,d - p),p);return k;};

global.Servernacl_uint8array_concat = function (a,b){var c =new (global.Uint8Array)(a.byteLength + b.byteLength);c.set(a,0);c.set(b,a.byteLength);return c;};

global.Servernacl_uint8array_fill = function (a,b){var c =0;for (; c < a.byteLength; c++){a[c] = b;}};

global.Servernacl_uint8array_repeat = function (a,b){if (b <= 0) {return new (global.Uint8Array)([]);} else {var c =a.byteLength,e =new (global.Uint8Array)(b * c),d =0;for (; d < b; d++){e.set(a,d * c);}return e;}};

global.Servernacl_uint8array_xor = function (a,b){if (a.byteLength == b.byteLength) {var c =0;for (; c < a.byteLength; c++){a[c] = a[c] ^ b[c];}}};

global.Servernacl_HMACtest = function (){var b =[{key:"0b0b0b0b0b0b0b0b0b0b0b0b0b0b0b0b0b0b0b0b",data:"4869205468657265",res:"87aa7cdea5ef619d4ff0b4241a1d6cb02379f4e2ce4ec2787ad0b30545e17cdedaa833b7d6b8a702038b274eaea3f4e4be9d914eeb61f1702e696c203a126854"},{key:"4a656665",data:"7768617420646f2079612077616e7420666f72206e6f7468696e673f",res:"164b7a7bfcf819e2e395fbe73b56e0a387bd64222e831fd610270cd7ea2505549758bf75c05a994a6d034f65f8f0e6fdcaeab1a34d4a6b4b636e070a38bce737"},{key:"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa",data:"dddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddd",res:"fa73b0089d56a284efb0f0756c890be9b1b5dbdd8ee81a3655f83e33b2279d39bf3e848279a722c806b485a47e67c807b946a337bee8942674278859e13292fb"},{key:"0102030405060708090a0b0c0d0e0f10111213141516171819",data:"cdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcd",res:"b0ba465637458c6990e5a8c5f61d4af7e576d97ff94b872de76f8050361ee3dba91ca5c11aa25eb4d679275cc5788063a5f19741120c4f2de2adebeb10a298dd"},{key:"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa",data:"54657374205573696e67204c6172676572205468616e20426c6f636b2d53697a65204b6579202d2048617368204b6579204669727374",res:"80b24263c7c1a3ebb71493c1dd7be8b49b46d1f41b4aeec1121b013783f8f3526b56d037e05f2598bd0fd2215d6a1e5295e64f73f63f0aec8b915a985d786598"},{key:"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa",data:"5468697320697320612074657374207573696e672061206c6172676572207468616e20626c6f636b2d73697a65206b657920616e642061206c6172676572207468616e20626c6f636b2d73697a6520646174612e20546865206b6579206e6565647320746f20626520686173686564206265666f7265206265696e6720757365642062792074686520484d414320616c676f726974686d2e",res:"e37b6a775dc87dbaa4dfa9f96e5e3ffddebd71f8867289865df5a32d20cdc944b6022cac3c4982b10d5eeb55c3e4de15134676fb6de0446065c97440fa8c6a58"}],a =0;for (; a < b.length; a++){var c =b[a],d =global.Servernacl_uint8array_decodeHex(c.key),e =global.Servernacl_uint8array_decodeHex(c.data);c = global.Servernacl_uint8array_decodeHex(c.res);d = global.Servernacl_hmac_sha512(d,e);global.nacl.verify(c,d)?global.console.log("[HMAC]","test #" + a + " successful"):c.byteLength != d.byteLength?global.console.log("[HMAC]","test #" + a + " failed (bad length)"):global.console.log("[HMAC]","test #" + a + " failed (bad length)");}};

global.Servernacl_PBKDF2test = function (){var b =[{pass:"password",salt:"salt",c:1,len:64,res:"867f70cf1ade02cff3752599a3a53dc4af34c7a669815ae5d513554e1c8cf252c02d470a285a0501bad999bfe943c08f050235d7d68b1da55e63f73b60a57fce"},{pass:"password",salt:"salt",c:2,len:64,res:"e1d9c16aa681708a45f5c7c4e215ceb66e011a2e9f0040713f18aefdb866d53cf76cab2868a39b9f7840edce4fef5a82be67335c77a6068e04112754f27ccf4e"},{pass:"password",salt:"salt",c:4096,len:64,res:"d197b1b33db0143e018b12f3d1d1479e6cdebdcc97c5c0f87f6902e072f457b5143f30602641b3d55cd335988cb36b84376060ecd532e039b742a239434af2d5"},{pass:"passwordPASSWORDpassword",salt:"saltSALTsaltSALTsaltSALTsaltSALTsalt",c:4096,len:64,res:"8c0511f4c6e597c6ac6315d8f0362e225f3c501495ba23b868c005174dc4ee71115b59f9e60cd9532fa33e0f75aefe30225c583a186cd82bd4daea9724a3d3b8"},{pass:"passDATAb00AB7YxDTT",salt:"saltKEYbcTcXHCBxtjD",c:1,len:64,res:"CBE6088AD4359AF42E603C2A33760EF9D4017A7B2AAD10AF46F992C660A0B461ECB0DC2A79C2570941BEA6A08D15D6887E79F32B132E1C134E9525EEDDD744FA"},{pass:"passDATAb00AB7YxDTT",salt:"saltKEYbcTcXHCBxtjD",c:100000,len:64,res:"ACCDCD8798AE5CD85804739015EF2A11E32591B7B7D16F76819B30B0D49D80E1ABEA6C9822B80A1FDFE421E26F5603ECA8A47A64C9A004FB5AF8229F762FF41F"},{pass:"passDATAb00AB7YxDTTl",salt:"saltKEYbcTcXHCBxtjD2",c:1,len:64,res:"8E5074A9513C1F1512C9B1DF1D8BFFA9D8B4EF9105DFC16681222839560FB63264BED6AABF761F180E912A66E0B53D65EC88F6A1519E14804EBA6DC9DF137007"},{pass:"passDATAb00AB7YxDTTl",salt:"saltKEYbcTcXHCBxtjD2",c:100000,len:64,res:"594256B0BD4D6C9F21A87F7BA5772A791A10E6110694F44365CD94670E57F1AECD797EF1D1001938719044C7F018026697845EB9AD97D97DE36AB8786AAB5096"},{pass:"passDATAb00AB7YxDTTlRH2dqxDx19GDxDV1zFMz7E6QVqKIzwOtMnlxQLttpE5",salt:"saltKEYbcTcXHCBxtjD2PnBh44AIQ6XUOCESOhXpEp3HrcGMwbjzQKMSaf63IJe",c:1,len:63,res:"E2CCC7827F1DD7C33041A98906A8FD7BAE1920A55FCB8F831683F14F1C3979351CB868717E5AB342D9A11ACF0B12D3283931D609B06602DA33F8377D1F1F99"},{pass:"passDATAb00AB7YxDTTlRH2dqxDx19GDxDV1zFMz7E6QVqKIzwOtMnlxQLttpE5",salt:"saltKEYbcTcXHCBxtjD2PnBh44AIQ6XUOCESOhXpEp3HrcGMwbjzQKMSaf63IJe",c:100000,len:63,res:"07447401C85766E4AED583DE2E6BF5A675EABE4F3618281C95616F4FC1FDFE6ECBC1C3982789D4FD941D6584EF534A78BD37AE02555D9455E8F089FDB4DFB6"},{pass:"passDATAb00AB7YxDTTlRH2dqxDx19GDxDV1zFMz7E6QVqKIzwOtMnlxQLttpE57",salt:"saltKEYbcTcXHCBxtjD2PnBh44AIQ6XUOCESOhXpEp3HrcGMwbjzQKMSaf63IJem",c:1,len:63,res:"B029A551117FF36977F283F579DC7065B352266EA243BDD3F920F24D4D141ED8B6E02D96E2D3BDFB76F8D77BA8F4BB548996AD85BB6F11D01A015CE518F9A7"},{pass:"passDATAb00AB7YxDTTlRH2dqxDx19GDxDV1zFMz7E6QVqKIzwOtMnlxQLttpE57",salt:"saltKEYbcTcXHCBxtjD2PnBh44AIQ6XUOCESOhXpEp3HrcGMwbjzQKMSaf63IJem",c:100000,len:63,res:"31F5CC83ED0E948C05A15735D818703AAA7BFF3F09F5169CAF5DBA6602A05A4D5CFF5553D42E82E40516D6DC157B8DAEAE61D3FEA456D964CB2F7F9A63BBBD"},{pass:"passDATAb00AB7YxDTT",salt:"saltKEYbcTcXHCBxtjD",c:1,len:65,res:"CBE6088AD4359AF42E603C2A33760EF9D4017A7B2AAD10AF46F992C660A0B461ECB0DC2A79C2570941BEA6A08D15D6887E79F32B132E1C134E9525EEDDD744FA88"},{pass:"passDATAb00AB7YxDTT",salt:"saltKEYbcTcXHCBxtjD",c:100000,len:65,res:"ACCDCD8798AE5CD85804739015EF2A11E32591B7B7D16F76819B30B0D49D80E1ABEA6C9822B80A1FDFE421E26F5603ECA8A47A64C9A004FB5AF8229F762FF41F7C"},{pass:"passDATAb00AB7YxDTTl",salt:"saltKEYbcTcXHCBxtjD2",c:1,len:65,res:"8E5074A9513C1F1512C9B1DF1D8BFFA9D8B4EF9105DFC16681222839560FB63264BED6AABF761F180E912A66E0B53D65EC88F6A1519E14804EBA6DC9DF1370070B"},{pass:"passDATAb00AB7YxDTTl",salt:"saltKEYbcTcXHCBxtjD2",c:100000,len:65,res:"594256B0BD4D6C9F21A87F7BA5772A791A10E6110694F44365CD94670E57F1AECD797EF1D1001938719044C7F018026697845EB9AD97D97DE36AB8786AAB5096E7"}],a =0;for (; a < b.length; a++){var c =b[a],d =global.nacl.util.decodeUTF8(c.pass),e =global.nacl.util.decodeUTF8(c.salt),f =global.Servernacl_uint8array_decodeHex(c.res);e = global.Servernacl_pbkdf2(d,e,c.c,c.len);global.nacl.verify(f,e)?global.console.log("[PBKDF2]","test #" + a + " successful"):f.byteLength != e.byteLength?global.console.log("[PBKDF2]","test #" + a + " failed (bad length)"):global.console.log("[PBKDF2]","test #" + a + " failed (bad content)");}};
