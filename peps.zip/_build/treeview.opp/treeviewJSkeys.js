// Checking keys resolution.
// File used by the jschecker only
var _check_definition_of_treeview_build = global.Treeview_build
var _check_definition_of_treeview_getselectednode = global.Treeview_getSelectedNode
var _check_definition_of_treeview_options = global.Treeview_options
var _check_definition_of_treeview_remove = global.Treeview_remove
