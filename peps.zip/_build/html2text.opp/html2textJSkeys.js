// Checking keys resolution.
// File used by the jschecker only
