global.htmlToText = require("html-to-text");


global.Html2text_html2text = function (a,b){var c =b.wordwrap;b = b.tables.all?true:b.tables.select;return global.htmlToText.fromString(a,{tables:b,wordwrap:c});};
